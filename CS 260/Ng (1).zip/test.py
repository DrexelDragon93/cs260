#!/usr/bin/env python

list = [1, 2, 3, 5]

# array implementation
def end_a(l):
	last = len(l)
	return l[last - 1]

def insert_a(l,p,x):
	array1 = l[0:p]
	array2 = l[p + 1:]
	array1.append(x)
	return array1 + array2
	
def delete_a(l,p):
	array1 = l[:p]
	array2 = l[p + 1:]
	return array1 + array2
	
def locate_a(l,x):
	end = len(l) - 1
	for i in range(0, end + 1):
		if l[i] == x:
			return i
		elif (i == end):
			return end
			
# pointer implementation
class node:
	def __init__(self, data, next = None):
		self.data = data
		self.next = next
		
	def __str__( self ):
		return "(%s, %s)" % ( self.data, self.next )
				
A= node(1,node(2,node(3,node(4,node(5,None)))))


def end_p(l):
	while l.next != None:
		l = l.next
	return l

def insert_p(l,p,x):
	temp1 = None
	for i in range(0,p+1):
		temp1 = node(l.data,temp1)
		l = l.next
	temp1.data = x
	while l != None:
		temp1 = node(l.data,temp1)
		l = l.next
	temp2 = None
	while temp1 != None:
		temp2 = node(temp1.data, temp2)
		temp1 = temp1.next
	return temp2

def delete_p(l,p):
	temp1 = None
	for i in range(0,p):
		temp1 = node(l.data,temp1)
		l = l.next
	l = l.next
	while l != None:
		temp1 = node(l.data,temp1)
		l = l.next
	temp2 = None
	while temp1 != None:
		temp2 = node(temp1.data, temp2)
		temp1 = temp1.next
	return temp2

def locate_p(l,x):
	pos = 0
	while l != None:
		if l.data == x:
			return pos
		l = l.next
		pos = pos + 1
	
def main():
	print locate_p(A,3)
if __name__ == '__main__':main()

