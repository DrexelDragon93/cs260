READ ME
The code was al written in python which made things with pointers a bit difficult. The implementation for pointers was done according to the examples from the provided book. 
There are four different python files one for each type of implementation. ([list:array],[list:pointer],[stack:array],[stack,pointer]) In each file there will be a commented 
section at the bottom which are the functions being put to use. So in order to see the python files outputting anything just uncomment what ever function needs to be checked. 
There should not be any special libraries that are needed and the files can be run in any linux environment by typing "python prog_name". The programs were tested on the drexel 
tx servers. Also, since python doesn't have any real pointers the INSERT and DELETE functions required some extra while loops to correct the format. All features of the program shown should work.


